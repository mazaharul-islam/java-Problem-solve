import java.util.Scanner;

    public class CountWordsCharVowelsCons {
        public static void main(String[] args) {
//        String address = "I live in Bangladesh";
//
//        //char charct[] = address.toCharArray();
//        //char charct[] = address.split(" ");
//        //System.out.println("Number of chars without spaces: " + charct.length);
//
//
//        String chart[] = address.split(" ");
//        System.out.println("Number of chars without spaces: "+ chart.length);
//
//        String[] words = address.split("\\s+");
//        System.out.println("Number of words: "+ words.length);

//
//        Scanner scanner = new Scanner(System.in);
//        System.out.print("Enter a string: ");
//        String string = scanner.nextLine();
//
//        int wordCount = 0;
//        int characterCount = 0;
//        int vowelCount = 0;
//        int consonantCount = 0;
//
//        for (int i = 0; i < string.length(); i++) {
//            char c = string.charAt(i);
//
//            if (c == ' ') {
//                wordCount++;
//            } else if (Character.isAlphabetic(c)) {
//                characterCount++;
//                if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' || c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
//                    vowelCount++;
//                } else {
//                    consonantCount++;
//                }
//            }
//        }
//
//        System.out.println("Number of words: " + wordCount);
//        System.out.println("Number of characters without spaces: " + characterCount);
//        System.out.println("Number of vowels: " + vowelCount);
//        System.out.println("Number of consonants: " + consonantCount);



//            public static int countWords(String string) {
//                int wordCount = 0;
//                for (int i = 0; i < string.length(); i++) {
//                    if (string.charAt(i) == ' ') {
//                        wordCount++;
//                    }
//                }
//                return wordCount + 1;
//            }
//
//            public static int countCharactersWithoutSpaces(String string) {
//                int characterCount = 0;
//                for (int i = 0; i < string.length(); i++) {
//                    if (string.charAt(i) != ' ') {
//                        characterCount++;
//                    }
//                }
//                return characterCount;
//            }
//
//            public static int countVowels(String string) {
//                int vowelCount = 0;
//                for (int i = 0; i < string.length(); i++) {
//                    if (string.charAt(i) == 'a' || string.charAt(i) == 'e' || string.charAt(i) == 'i' || string.charAt(i) == 'o' || string.charAt(i) == 'u' || string.charAt(i) == 'A' || string.charAt(i) == 'E' || string.charAt(i) == 'I' || string.charAt(i) == 'O' || string.charAt(i) == 'U') {
//                        vowelCount++;
//                    }
//                }
//                return vowelCount;
//            }
//
//            public static int countConsonants(String string) {
//                int consonantCount = 0;
//                for (int i = 0; i < string.length(); i++) {
//                    if (string.charAt(i) != 'a' && string.charAt(i) != 'e' && string.charAt(i) != 'i' && string.charAt(i) != 'o' && string.charAt(i) != 'u' && string.charAt(i) != 'A' && string.charAt(i) != 'E' && string.charAt(i) != 'I' && string.charAt(i) != 'O' && string.charAt(i) != 'U') {
//                        consonantCount++;
//                    }
//                }
//                return consonantCount;
//            }
//
//            {
//                Scanner scanner = new Scanner(System.in);
//                System.out.print("Enter a string: ");
//                String string = scanner.nextLine();
//
//                int wordCount = countWords(string);
//                int characterCount = countCharactersWithoutSpaces(string);
//                int vowelCount = countVowels(string);
//                int consonantCount = countConsonants(string);
//
//                System.out.println("Number of words: " + wordCount);
//                System.out.println("Number of characters without spaces: " + characterCount);
//                System.out.println("Number of vowels: " + vowelCount);
//                System.out.println("Number of consonants: " + consonantCount);
            }
        }
