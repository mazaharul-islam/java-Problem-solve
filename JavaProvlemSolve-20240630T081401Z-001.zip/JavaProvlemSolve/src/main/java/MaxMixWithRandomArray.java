/*A program thatGenerate random 10 integer numbers in an array and print out all the numbers from array
 and also print the max and min number from the array
 */
import java.util.Arrays;
import java.util.Random;

public class MaxMixWithRandomArray {
    public static void main(String[] args) {
        int[] numbers = randomArray(10);
        System.out.println("Numbers in the array: " + Arrays.toString(numbers));

        int max = findMax(numbers);
        int min = findMin(numbers);

        System.out.println("Max value is: " + max);
        System.out.println("Min value is : " + min);

    }

    static int[] randomArray(int size) {
        int[] array = new int[size];
        Random random = new Random();

        for (int i = 0; i < size; i++) {
            array[i] = random.nextInt(100);
        }
        return array;
    }

    static int findMax(int[] numbers) {
        int max = numbers[0];
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }
        return max;
    }

    static int findMin(int[] numbers) {
        int min = numbers[0];
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] < min) {
                min = numbers[i];
            }
        }
        return min;
    }

}
