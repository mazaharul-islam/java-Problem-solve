/*A core i 7 laptop price is 85000 tk and a gaming mouse price is 2500 tk.
 If I buy the laptop and 1 piece mouse, what will be my total cost after giving 15% discount?
 [Extract the digits from the paragraph and calculate the price]
  */
public class GetDigitsFromString {
    public static void main(String[] args) {

        String str = "A core i 7 laptop price is 85000 tk and a gaming mouse price is 2500 tk. If i buy the laptop and 1 piece mouse, what will be my total cost after giving 15% discount?";
        str = str.replaceAll("[^\\d]", " ");
        str = str.trim();
        str = str.replaceAll(" +", " ");
        String[] array = (str.split(" "));
        double laptopPrice = Double.parseDouble(array[1]);
        double MousePrice = Double.parseDouble(array[2]);
        double Price = laptopPrice + MousePrice;
        System.out.println("Total Price of Product is " + Price + " tk");
        double discount = Double.parseDouble(array[4]);
        double discountAmount = (Price * discount) / 100;
        System.out.println("Discount is  " + discountAmount + " tk");
        double total = (Price - discountAmount);
        System.out.println("After Discount price is " + total + " tk");


    }
}
