import java.util.Arrays;
public class binarySearch {
    public static void main(String[] args) {

        int[] numbers = {1, 6, 9, 3, 5, 4, 7};
        int key = 5;
        Arrays.sort(numbers);
        System.out.println(numbers);
        for (int i = 0; i < numbers.length; i++)
            System.out.print(numbers[i] + " ");
        int searchResult = binarySearch(numbers, key);

        if (searchResult == 0) {
            System.out.println("Key found at index: " + searchResult);
        } else {
            System.out.println(" Key not found ");
        }
    }

    static int binarySearch(int[] arry, int key) {
        int low = 0;
        int high = arry.length - 1;
        int mid = 0;

        while (low <= high) {
            mid = (low + high) / 2;

            if (arry[mid] == key) {
                return mid;
            } else if (arry[mid] > key) {
                high = mid - 1;

            } else {
                low = mid + 1;
            }
        }
        return -1;
    }
}






