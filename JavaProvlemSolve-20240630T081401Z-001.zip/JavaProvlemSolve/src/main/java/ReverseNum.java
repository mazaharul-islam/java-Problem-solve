/*A program to Take any number as input and print the reverse of the number
* Input:12345
* Output: 54321
* */
import java.util.Scanner;
public class ReverseNum {
    public static void main(String[] args) {
        int number;
        int reverse = 0;
        System.out.print("Enter your Number to want Reverse :" );
        Scanner scanner = new Scanner(System.in);
        number = scanner.nextInt();

        while (number != 0)
        {
            reverse = reverse * 10;
            reverse = reverse + number%10;
            number = number/10;
        }
        System.out.println("Reverse of the Number is : " + reverse);
    }

}
