/*Swap the value without a temp variable
* Input :a=10 and b=20
* Output: a=20, b=10*/

public class SwapValuesWithoutTemp {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;

        //swap the values using (+) and (-)
        a = a + b;//a is now 30
        b = a - b;//b is now 10
        a = a - b;// a is now 20
        System.out.println("Output: a = " + a + " b = " + b);

    }
}
