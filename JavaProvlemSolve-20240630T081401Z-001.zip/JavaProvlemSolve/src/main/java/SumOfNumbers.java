/*A program that will take integer numbers as user input continuously and print the sum of numbers until user
input q from the keyboard. When user input q, program will be quit.
If user inputs another character, then the program will ask to input the number again.
 */

import java.util.Scanner;

public class SumOfNumbers {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int sum = 0;
        do {
            System.out.print("Please Enter integers: ");
            String input = scanner.next();

            if (input.equals("q")) {
                break;
            }
            //using Try & catch blocks for Exception Handling
            try {
                int number = Integer.parseInt(input);
                sum += number;
            } catch (NumberFormatException e) {
                System.out.println("Do you want sum of Numbers...?. Please Enter integers: ");
            }

        } while (true);

        System.out.println("The sum of numbers is: " + sum);
    }
}
