/*Write a program that will shuffle (values will randomly change their position) from the given array
* Input: Numbers[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 0}
* Output: (values will randomly change their position)*/

import java.util.Arrays;
import java.util.Random;

public class ShuffleElement {
    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 0};
        Random random = new Random();
        for (int i = numbers.length - 1; i > 0; i--) {
            int ranNum = random.nextInt(i + 1);
            int temp = numbers[ranNum];
            numbers[ranNum] = numbers[i];
            numbers[i] = temp;
        }
        System.out.println("Random output:" + Arrays.toString(numbers));
    }
}
