/*Encrypt word: ROADTOSDET [when A=F]
* Output: WTFIYTXIJY
* */

public class EncryptedWord {
    public static void main(String[] args) {
        String OriginalWord = "ROADTOSDET";
        String encryptedWord = "";
        for (int i = 0; i < OriginalWord.length(); i++) {
            char ch = OriginalWord.charAt(i);

            if (ch >= 'a' && ch <= 'z') {
                ch = (char) (ch + 5);
                if (ch > 'z') {
                    ch = (char) (ch - 26);
                }
            } else if (ch >= 'A' && ch <= 'Z') {
                ch = (char) (ch + 5);
                if (ch > 'Z') {
                    ch = (char) (ch - 26);
                }
            }
            encryptedWord += ch;
        }

        System.out.println("Encrypted word is: " + encryptedWord);
    }
}

