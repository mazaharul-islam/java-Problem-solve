/*Swap the value using a temp variable
* Input:a=10 and b=20
* Output: a=20 and b=10
* */

public class SwapValues {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;

        // Use a temporary variable to store the value of a
        int temp = a;
        // Assign the value of b to a
        a = b;
        // Assign the value of the temporary variable to b
        b = temp;

        System.out.println("Output: a = " + a + " b = " + b);
    }
}
