public class StringManipulation {
    public static void main(String[] args) {
        String mystr = "I live In Bangladesh";
        char[] arr = mystr.toCharArray();

        System.out.println(arr.length);

        for (char ch : arr) {
            System.out.println(ch);
        }
        String amount = "100 Dollar";
        String[] myAmount = amount.split(" ");
        System.out.println(myAmount[0]);

        //Total Words in the String
        String address[] = mystr.split(" ");
        System.out.println(address.length);

        String mystring = "I live In Mymensingh trishal";
        String add[] = mystring.split("\\s");
        System.out.println(add.length);

    }
}
