/* A program to Extract the OTP from the SMS. "Your one time password is 246148.
 Don't share this code with anyone \r\nBvwt3f8js2S
 */
public class Regex {
    public static void main(String[] args) {
        String message= "Your secret code is 246148. don’t share with anybody.\r\nBvwt3f8js2S";
        String code=message.replaceAll("[^\\d]", "").substring(0, 6);
        System.out.println(code);

    }
}
