/*Write a program that will find your key is found in the given array using linear search method
Input: numbers=[1,6,9,3,5,4,7]
key=5
output: Element found at index: 4
*/
public class linearSearch {
    public static void main(String[] args) {
        int numbers[] = {1, 6, 9, 3, 5, 4, 7};
        int key = 5;
        boolean flag = false;
        for (int i = 0; i < numbers.length; i++) {
            if (key == numbers[i]) {
                System.out.println("Element found at index :" + i);
                flag = true;
                break;
            }
        }
        if (flag == false) {
            System.out.println("Element Not found ");
        }
    }
}
