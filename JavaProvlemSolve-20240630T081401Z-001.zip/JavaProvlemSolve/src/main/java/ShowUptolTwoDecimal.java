/*--print the value upto 2 decimal point-----------***/
public class ShowUptolTwoDecimal {
    public static void main(String[] args) {
        double a  = 15.5276;
        System.out.printf(" Output: a = %.2f", a);
    }
}
