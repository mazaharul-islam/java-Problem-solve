import java.util.Scanner;

public class CountWordChVowelCons {
    public static void main(String[] args) {
        String str = "This is a string with some vowels and consonants.";

        // Function to count the number of words in a string
        int numWords = countWords(str);

        // Function to count the number of characters without spaces in a string
        int numCharactersWithoutSpaces = countCharactersWithoutSpaces(str);

        // Function to count the number of vowels in a string
        int numVowels = countVowels(str);

        // Function to count the number of consonants in a string
        int numConsonants = countConsonants(str);

        // Print the results
        System.out.println("The number of words in the string is: " + numWords);
        System.out.println("The number of characters without spaces in the string is: " + numCharactersWithoutSpaces);
        System.out.println("The number of vowels in the string is: " + numVowels);
        System.out.println("The number of consonants in the string is: " + numConsonants);
    }

    private static int countWords(String str) {
        int numWords = 0;
        String[] words = str.split(" ");
        numWords = words.length;
        return numWords;
    }

    private static int countCharactersWithoutSpaces(String str) {
        int numCharactersWithoutSpaces = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != ' ') {
                numCharactersWithoutSpaces++;
            }
        }
        return numCharactersWithoutSpaces;
    }

    private static int countVowels(String str) {
        int numVowels = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) == 'a' || str.charAt(i) == 'e' || str.charAt(i) == 'i' || str.charAt(i) == 'o' || str.charAt(i) == 'u') {
                numVowels++;
            }
        }
        return numVowels;
    }

    private static int countConsonants(String str) {
        int numConsonants = 0;
        for (int i = 0; i < str.length(); i++) {
            if (str.charAt(i) != 'a' && str.charAt(i) != 'e' && str.charAt(i) != 'i' && str.charAt(i) != 'o' && str.charAt(i) != 'u') {
                numConsonants++;
            }
        }
        return numConsonants;
    }
}

