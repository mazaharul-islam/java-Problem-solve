import java.util.Scanner;

public class palindrome {
    public static void main(String[] args) {
        Scanner mystring = new Scanner(System.in);
        System.out.println("Enter your String Please ");
        String rev = "";
        String OriginalString = mystring.next();
        if (OriginalString.equals (rev)) {
            System.out.println(OriginalString + true);
        } else{
            System.out.println(OriginalString + " is a not Palindrome");
        }

    }

    static String reverseString(String str) {
        char ch[] = str.toCharArray();
        String rev = "";
        for (int i = ch.length - 1; i >= 0; i--) {
            rev += ch[i];
        }
        return rev;

    }
}
