/*Find out the second largest element of the given array--
* input: a[] = {5, 3, 9, 7, 4, 1, 8}
* Output: 8*/

public class SecondLargestNum {
    public static void main(String[] args) {

        //init the Array
        int a[] = {5, 3, 9, 7, 4, 1, 8};

        // Declare two variable for largest & 2nd largest number
        int largestEl = a[0];
        int secLargeEl = a[1];

        //Traverse the loop
        for (int i = 0; i < a.length; i++) {
            if (a[i] > largestEl) {
                secLargeEl = largestEl;
                largestEl = a[i];
            } else if (a[i] > secLargeEl && a[i] != largestEl){
                secLargeEl = a[i];

            }

        }
        //print the second largest Element of given Array
        System.out.println("The second largest Element : " + secLargeEl);
    }
}